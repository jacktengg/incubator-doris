# export BUILD_TYPE=RELEASE
# export EXTRA_CXX_FLAGS="-O3"

export EXTRA_CXX_FLAGS="-O3"
export BUILD_TYPE=RELEASE








# export DISABLE_JAVA_CHECK_STYLE=ON
# export DISABLE_BE_JAVA_EXTENSIONS=ON


# export BUILD_TYPE_UT=Release

export ENABLE_PCH=off

export JDK_17=/mnt/disk2/tengjianping/local/jdk-17.0.2
export DORIS_TOOLCHAIN=clang

export DORIS_TOOLCHAIN=clang
