<!--
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
-->

| Case | V1 ms | V2 ms | Migrated ms [min,max] | vs V2 | Peak MiB (V2 → migrated) |
| --- | ---: | ---: | ---: | ---: | ---: |
| numeric_low_null0 | 36.95 | 36.36 | 40.33 [37.45,44.27] | +10.9% | 244.0 → 242.8 |
| numeric_high_null0 | 187.57 | 175.71 | 168.68 [162.66,181.67] | -4.0% | 812.1 → 809.2 |
| variadic_null0 | 82.68 | 84.81 | 67.39 [63.33,77.58] | -20.5% | 308.2 → 288.1 |
| numeric_low_null1 | 34.87 | 36.96 | 38.49 [31.90,45.75] | +4.1% | 213.4 → 243.2 |
| numeric_high_null1 | 185.39 | 182.17 | 169.76 [158.89,195.10] | -6.8% | 764.3 → 765.2 |
| variadic_null1 | 83.20 | 88.33 | 74.90 [63.68,93.75] | -15.2% | 276.9 → 290.4 |
| numeric_low_null50 | 40.58 | 38.52 | 39.07 [35.76,47.28] | +1.4% | 234.6 → 259.5 |
| numeric_high_null50 | 200.03 | 195.93 | 174.17 [159.79,199.76] | -11.1% | 794.5 → 806.9 |
| variadic_null50 | 87.60 | 82.57 | 64.88 [62.51,67.42] | -21.4% | 285.3 → 297.6 |
| numeric_low_null100 | 33.32 | 33.27 | 32.41 [30.74,34.72] | -2.6% | 223.1 → 234.9 |
| numeric_high_null100 | 106.95 | 172.07 | 116.73 [110.76,128.57] | -32.2% | 781.3 → 743.0 |
| variadic_null100 | 64.58 | 65.10 | 47.96 [45.15,54.87] | -26.3% | 284.6 → 284.3 |
| wide_string_set | 1219.02 | 1243.99 | 1227.60 [1198.74,1277.42] | -1.3% | 2679.6 → 2784.6 |
| wide_string_streaming | 351.55 | 354.63 | 327.45 [302.30,341.76] | -7.7% | 1020.8 → 1062.0 |
| wide_topn | 537.22 | 549.17 | 560.33 [512.23,632.30] | +2.0% | 348.9 → 372.9 |
| stored_merge | 62.42 | 63.17 | 65.26 [62.01,68.75] | +3.3% | 188.3 → 188.1 |
| stored_union_finalize | 15.84 | 15.93 | 16.26 [14.70,17.60] | +2.1% | 218.8 → 218.8 |
| stored_bulk_merge | 45.58 | 44.68 | 46.49 [44.58,48.44] | +4.1% | 262.1 → 246.3 |
| stored_bulk_union_finalize | 29.45 | 29.96 | 28.61 [27.39,29.82] | -4.5% | 175.1 → 173.6 |
| stored_bulk_wide | 735.57 | 740.64 | 711.13 [697.90,721.30] | -4.0% | 1066.6 → 1083.4 |
| tpcds_sf1_q78 | 134.46 | 135.66 | 132.67 [118.99,156.51] | -2.2% | 1668.9 → 1672.3 |
