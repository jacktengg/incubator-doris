import datetime
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd()
out = root/'output/nullable-v2-recheck'
p = out/'current'
cases = {
 'reference': ['streaming/nullable_sum/4096/100/1', 'merge/nullable_decimal_avg/4096/1/1/64'],
 'migrated': ['streaming/nullable_sum/4096/100/1', 'merge/nullable_sum/4096/1/1/64'],
}
commands=[]
for label, names in cases.items():
 env=os.environ.copy()
 env['DORIS_HOME']=str(out/('reference-runtime' if label=='reference' else 'performance')/'be')
 env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
 original=p/f'{label}-timing.json'
 (p/f'{label}-timing-initial.json').write_bytes(original.read_bytes())
 target=p/f'{label}-timing-recheck.json'
 cmd=['taskset','-c','12',str(out/'bin'/f'{label}-timing-benchmark'),
      '--benchmark_filter=^('+'|'.join(names)+')$', '--benchmark_min_time=5s',
      '--benchmark_min_warmup_time=1', '--benchmark_repetitions=5',
      '--benchmark_out='+str(target),'--benchmark_out_format=json']
 record={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (p/f'{label}-timing-recheck.log').open('w') as f:
  subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 commands.append(record)
 d=json.loads(original.read_text()); d['benchmarks']+=json.loads(target.read_text())['benchmarks']
 original.write_text(json.dumps(d,indent=2)+'\n')
 print(label,'recheck complete',flush=True)
(p/'kernel-recheck-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
