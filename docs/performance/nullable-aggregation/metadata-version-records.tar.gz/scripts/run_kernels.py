import datetime
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd()
out = root / 'output/nullable-v2-recheck'
current = out / 'current'
commands = []
for label, mode in [('reference', '(0|1)'), ('migrated', '1')]:
    env = os.environ.copy()
    env['DORIS_HOME'] = str(out / ('reference-runtime' if label == 'reference' else 'performance') / 'be')
    env['LD_LIBRARY_PATH'] = '/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:' + env.get('LD_LIBRARY_PATH', '')
    pattern = f'nullable_.*/4096/(0|1|50|100)/{mode}($|/)'
    for variant in ['timing', 'allocation']:
        cmd = ['taskset', '-c', '12', str(out / 'bin' / f'{label}-{variant}-benchmark'),
               '--benchmark_filter=' + pattern,
               '--benchmark_min_time=' + ('0.5s' if variant == 'timing' else '0.001s'),
               '--benchmark_min_warmup_time=' + ('0.1' if variant == 'timing' else '0'),
               '--benchmark_repetitions=' + ('5' if variant == 'timing' else '1'),
               '--benchmark_out=' + str(current / f'{label}-{variant}.json'),
               '--benchmark_out_format=json']
        record = {'command': cmd, 'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'DORIS_HOME': env['DORIS_HOME']}
        commands.append(record)
        log = current / f'{label}-{variant}.log'
        with log.open('w') as target:
            result = subprocess.run(cmd, env=env, stdout=target, stderr=subprocess.STDOUT)
        record['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        record['exit_code'] = result.returncode
        (current / 'kernel-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        assert result.returncode == 0, log
        if variant == 'allocation':
            rows = [json.loads(line.removeprefix('NULLABLE_ALLOCATIONS ')) for line in log.read_text().splitlines()
                    if line.startswith('NULLABLE_ALLOCATIONS ')]
            assert len(rows) == (96 if label == 'reference' else 48), len(rows)
            assert all(row['operations'] > 0 for row in rows)
            (current / f'{label}-allocations.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
        print(label, variant, 'finished', flush=True)
