import datetime
import json
import os
from pathlib import Path
import subprocess

root=Path.cwd();out=root/'output/nullable-v2-recheck';p=out/'final'
commands=[]
for index,label in enumerate(('final','c72','reference','final','single-store','final')):
 binary={'final':'sum-timing-benchmark','c72':'migrated-timing-benchmark','reference':'reference-timing-benchmark','single-store':'sum-single-store-timing-benchmark'}.get(label)
 # The single-store binary was overwritten by the final build; its earlier records
 # remain separate. Use c72 again for an unchanged-binary time check.
 if label=='single-store':label='c72';binary='migrated-timing-benchmark'
 env=os.environ.copy();env['DORIS_HOME']=str(out/('reference-runtime' if label=='reference' else 'performance')/'be')
 env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
 target=p/f'process-probe-{index}-{label}'
 cmd=['taskset','-c','12',str(out/'bin'/binary),'--benchmark_filter=^merge/nullable_decimal_avg/4096/1/1/64$',
      '--benchmark_min_time=1s','--benchmark_min_warmup_time=1','--benchmark_repetitions=10',
      '--benchmark_out='+str(target)+'.json','--benchmark_out_format=json']
 record={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with Path(str(target)+'.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();commands.append(record)
 (p/'process-probe-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 data=json.loads(Path(str(target)+'.json').read_text());values=[v['cpu_time']/1000 for v in data['benchmarks'] if v['run_type']=='iteration']
 print(index,label,values,flush=True)
 if label in ('final','reference'):
  original=p/('migrated-timing.json' if label=='final' else 'reference-timing.json')
  combined=json.loads(original.read_text());combined['benchmarks']+=data['benchmarks']
  tmp=original.with_suffix('.tmp');tmp.write_text(json.dumps(combined,indent=2)+'\n');tmp.replace(original)
