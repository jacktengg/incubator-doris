import datetime
import json
import os
from pathlib import Path
import subprocess

root=Path.cwd();out=root/'output/nullable-v2-recheck';p=out/'final'
records=[]
for label in ('migrated',):
 env=os.environ.copy()
 env['DORIS_HOME']=str(out/('performance' if label=='migrated' else 'reference-runtime')/'be')
 env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
 env['PERF_BUILDID_DIR']=str(out/'perf-buildid')
 binary=out/'bin'/'sum-timing-benchmark'
 target=p/f'{label}-all-null-diagnostic'
 command=['perf','record','-e','cycles','-F','199','--call-graph','fp','-o',str(target)+'.perf.data','--','taskset','-c','12',str(binary),
          '--benchmark_filter=^streaming/nullable_sum/4096/100/1$', '--benchmark_min_time=1s',
          '--benchmark_min_warmup_time=1','--benchmark_repetitions=10',
          '--benchmark_out='+str(target)+'.json','--benchmark_out_format=json']
 record={'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with Path(str(target)+'.log').open('w') as f:
  result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['exit_code']=result.returncode
 records.append(record);(p/'all-null-diagnostic-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0
 with Path(str(target)+'-hotspots.txt').open('w') as f:
  subprocess.run(['perf','report','--stdio','--no-children','--sort','symbol','-i',str(target)+'.perf.data'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(label,'profile complete',flush=True)
