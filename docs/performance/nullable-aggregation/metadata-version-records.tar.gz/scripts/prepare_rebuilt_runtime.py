import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path.cwd()
p = root / 'output/nullable-v2-recheck'
records = p / 'final'
runtime = p / 'performance'
old_hash = '56526dab509b1480e6ab15a5fdee2c03cea0345a483bcad82aaae44a97ab9cd4'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

new_binary = root / 'output/be/lib/doris_be'
assert sha(new_binary) != old_hash, 'The production BE must be relinked.'
for part in ('fe', 'be'):
    assert not (runtime / part / 'bin' / (part + '.pid')).exists()

# Keep earlier data for inspection. Copy the stopped original snapshot for timing.
for part, name in [('fe', 'doris-meta'), ('be', 'storage')]:
    src = p / 'reference-snapshot' / part / name
    dst = runtime / part / name
    dst.rename(p / ('pre-runtime-rebuild-' + part + '-' + name))
    subprocess.run(['cp', '-a', '--reflink=auto', str(src), str(dst)], check=True)
shutil.copyfile(new_binary, runtime / 'be/lib/doris_be')
assert sha(runtime / 'be/lib/doris_be') == sha(new_binary)

# Each removed record has a hard-link copy in pre-runtime-rebuild. Remove the
# final directory entry before a driver writes it, to keep that copy unchanged.
patterns = ['migrated-*.profile.txt.gz', 'migrated-queries.json',
            'migrated-metrics.json', 'migrated-audit.log.gz', 'migrated-stability.json',
            'migrated*query*', 'sql-stability-commands.json',
            'fixed-count-compaction.json', 'mixed-old-schema-compaction.json',
            'query-summary.*', 'operator-summary.*']
for pattern in patterns:
    for file in records.glob(pattern):
        file.unlink()
hash_file = records / 'binary-hashes.json'
hashes = json.loads(hash_file.read_text())
hashes['output/nullable-v2-recheck/performance/be/lib/doris_be'] = sha(new_binary)
hash_file.unlink()
hash_file.write_text(json.dumps(hashes, indent=2) + '\n')
print('Fresh old-data snapshot and newly linked runtime are ready:', sha(new_binary))
