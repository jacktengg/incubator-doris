import datetime
import json
import os
from pathlib import Path
import statistics
import subprocess

root=Path.cwd();out=root/'output/nullable-v2-recheck';final=out/'final'
cpu=json.loads((final/'cpu-placement-probe.json').read_text())['selected_cpu']
target=final/f'cpu{cpu}-probe';target.mkdir(exist_ok=True)
cases=['streaming/nullable_sum/4096/100/1','merge/nullable_sum/4096/50/1/64','merge/nullable_avg/4096/100/1/64','merge/nullable_decimal_avg/4096/1/1/64']
commands=[];summary=[]
for index,name in enumerate(cases):
 row={'case':name,'cpu':cpu}
 for label in (('reference-v2','migrated') if index%2==0 else ('migrated','reference-v2')):
  env=os.environ.copy();env['DORIS_HOME']=str(out/('performance' if label=='migrated' else 'reference-runtime')/'be')
  env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
  binary=out/'bin'/('sum-timing-benchmark' if label=='migrated' else 'reference-timing-benchmark')
  stem=target/f'{index}-{label}'
  cmd=['taskset','-c',str(cpu),str(binary),'--benchmark_filter=^'+name+'$',
       '--benchmark_min_time=2s','--benchmark_min_warmup_time=1','--benchmark_repetitions=5',
       '--benchmark_out='+str(stem)+'.json','--benchmark_out_format=json']
  record={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with Path(str(stem)+'.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();commands.append(record)
  (target/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  values=[r['cpu_time']/1000 for r in json.loads(Path(str(stem)+'.json').read_text())['benchmarks'] if r['run_type']=='iteration']
  row[label]={'cpu_us_mean':statistics.mean(values),'cpu_us_median':statistics.median(values),'min':min(values),'max':max(values),'cv':statistics.stdev(values)/statistics.mean(values),'values':values}
  print(index,label,values,flush=True)
 row['change_vs_v2_pct']=(row['migrated']['cpu_us_mean']/row['reference-v2']['cpu_us_mean']-1)*100
 summary.append(row);(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
