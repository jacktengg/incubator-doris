import datetime
import json
import gzip
import re
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import pymysql

root=Path.cwd()
out=root/'output/nullable-v2-recheck'
current=out/'final'
scripts=root/'docs/performance/nullable-aggregation'
env=os.environ.copy()
for key in ('http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','all_proxy'):
 env.pop(key,None)
env['PERF_BUILDID_DIR']=str(out/'perf-buildid')
env['JAVA_HOME']='/mnt/disk2/tengjianping/local/jdk-17.0.2'
records=[]

def save():
 (current/'sql-stability-commands.json').write_text(json.dumps(records,indent=2)+'\n')

def run(cmd,name,cwd=root):
 record={'command':[str(v) for v in cmd], 'cwd':str(cwd), 'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record);save()
 with (out/('actual-runtime-'+name+'.log')).open('w') as log:
  p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['exit_code']=p.returncode;record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 assert p.returncode==0,name

def connect():
 return pymysql.connect(host='127.0.0.1',port=29745,user='root',connect_timeout=3,read_timeout=600)

def start(runtime,label):
 for part in ('fe','be'):
  assert not (runtime/part/'bin'/f'{part}.pid').exists(),runtime
  run(['bin/start_'+part+'.sh','--daemon'],label+'-'+part+'-start-stability',runtime/part)
 time.sleep(30)
 for attempt in range(180):
  try:
   with connect() as c, c.cursor() as s:
    s.execute('show backends')
    names=[v[0] for v in s.description]
    alive=[dict(zip(names,row)) for row in s.fetchall()]
    if len(alive)==1 and str(alive[0]['Alive']).lower()=='true':
     pid=(runtime/'be/bin/be.pid').read_text().strip()
     exe=Path('/proc')/pid/'exe'
     import hashlib
     h=hashlib.sha256()
     with exe.open('rb') as f:
      while block:=f.read(1024*1024):h.update(block)
     expected=json.loads((current/'binary-hashes.json').read_text())['output/nullable-v2-recheck/performance/be/lib/doris_be']
     assert h.hexdigest()==expected,(h.hexdigest(),expected)
     records.append({'runtime_pid':pid,'runtime_executable':str(exe.resolve()),'runtime_sha256':h.hexdigest()});save()
     print(label,'cluster ready; running BE hash verified',flush=True);return
  except (pymysql.MySQLError,ConnectionError):
   pass
  time.sleep(1)
 raise RuntimeError('cluster not ready: '+label)

def stop(runtime,label):
 for part in ('fe','be'):
  run(['bin/stop_'+part+'.sh'],label+'-'+part+'-stop-stability',runtime/part)
  assert not (runtime/part/'bin'/f'{part}.pid').exists()

def cvs(label):
 data=json.loads((current/f'{label}-queries.json').read_text())['results']
 groups={}
 for row in data:groups.setdefault(row['case'],[]).append(row['wall_seconds'])
 return {name:statistics.stdev(values[-5:])/statistics.mean(values[-5:]) for name,values in groups.items()}

def measure(label,runtime):
 base=[sys.executable,str(scripts/'run_queries.py'),label,'--port','29745','--http-port','28745','--output',str(current),'--append','--v2','false' if label=='reference-v1' else 'true']
 run(base+['--repetitions','0'],label+'-stability-prewarm')
 for round_number in range(1,6):
  values=cvs(label)
  noisy=[name for name,value in values.items() if value>=.05]
  records.append({'label':label,'round':round_number,'last_five_cv_before':values,'repeat_cases':noisy});save()
  if not noisy:break
  print(label,'stability round',round_number,len(noisy),'cases',flush=True)
  run(base+['--cases',','.join(noisy),'--repetitions','5'],label+f'-stability-{round_number}')
 final=cvs(label)
 (current/f'{label}-stability.json').write_text(json.dumps({'criterion':'last five sample CV < 0.05; all samples retained','maximum_additional_rounds':5,'last_five_cv':final,'unresolved':[k for k,v in final.items() if v>=.05]},indent=2)+'\n')
 # Preserve audit records across daily rotations before joining query IDs.
 audit=out/f'{label}-complete-audit.log'
 ids={r['query_id'] for r in json.loads((current/f'{label}-queries.json').read_text())['results']}
 for attempt in range(60):
  previous=current/f'{label}-audit.log.gz'
  text=gzip.open(previous,'rt').read() if previous.exists() else ''
  for p in sorted((runtime/'fe/log').glob('fe.audit.log*')):
   if p.is_file():text += gzip.open(p,'rt').read() if p.suffix=='.gz' else p.read_text()
  audit.write_text(text)
  if ids.issubset(set(re.findall(r'\|QueryId=([^|]+)',text))):break
  time.sleep(1)
 else:raise RuntimeError('audit flush did not complete')
 run([sys.executable,str(scripts/'collect_metrics.py'),label,str(audit),'--output',str(current)],label+'-stability-metrics')
 print(label,'final noisy cases',[k for k,v in final.items() if v>=.05],flush=True)

migrated=out/'performance'
start(migrated,'sum-final')
base=[sys.executable,str(scripts/'run_queries.py'),'migrated','--port','29745','--http-port','28745','--output',str(current)]
run(base+['--repetitions','0'],'sum-final-sql-prewarm')
run(base+['--repetitions','10'],'sum-final-sql-initial')
measure('migrated',migrated)
for label,case in [('migrated','numeric_high_null1'),('migrated-wide','wide_string_set'),('migrated-variadic','variadic_null50')]:
 pid=(migrated/'be/bin/be.pid').read_text().strip()
 run([sys.executable,str(scripts/'capture_query_hotspots.py'),label,pid,'--queries-label','migrated',
      '--port','29745','--input',str(current),'--case',case,'--output',str(current/(label+'-query.perf.data'))],label+'-sum-final-hotspots')
run([sys.executable,str(scripts/'verify_upgrade.py'),'--port','29745','--be-http-port','28755','--output',str(current)],'sum-final-upgrade-compaction')
run([sys.executable,str(out/'final_fixed_count_compaction.py')],'sum-final-count-compaction')
run(['./run-regression-test.sh','--run','-d','datatype_p0/agg_state'],'sum-final-regression')
stop(migrated,'sum-final')
print('Final SQL, CPU profiles, compaction, and regression completed; cluster stopped',flush=True)
