import datetime
import json
import os
from pathlib import Path
import statistics
import subprocess

root=Path.cwd();out=root/'output/nullable-v2-recheck';p=out/'final/cpu37-probe'
env=os.environ.copy();env['DORIS_HOME']=str(out/'performance/be')
env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
cmd=['taskset','-c','37',str(out/'bin/sum-timing-benchmark'),'--benchmark_filter=^streaming/nullable_sum/4096/100/1$', '--benchmark_min_time=5s','--benchmark_min_warmup_time=5','--benchmark_repetitions=5','--benchmark_out='+str(p/'0-migrated-recheck.json'),'--benchmark_out_format=json']
record={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (p/'0-migrated-recheck.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(p/'recheck-command.json').write_text(json.dumps(record,indent=2)+'\n')
values=[r['cpu_time']/1000 for r in json.loads((p/'0-migrated-recheck.json').read_text())['benchmarks'] if r['run_type']=='iteration']
summary=json.loads((p/'summary.json').read_text());r=summary[0];v=r['migrated']['values']+values
r['migrated']={'cpu_us_mean':statistics.mean(v),'cpu_us_median':statistics.median(v),'min':min(v),'max':max(v),'cv':statistics.stdev(v)/statistics.mean(v),'values':v,'last_five_cv':statistics.stdev(values)/statistics.mean(values)}
r['change_vs_v2_pct']=(r['migrated']['cpu_us_mean']/r['reference-v2']['cpu_us_mean']-1)*100
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(values,'last five CV',r['migrated']['last_five_cv'])
