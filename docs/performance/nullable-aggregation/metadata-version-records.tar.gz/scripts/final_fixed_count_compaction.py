import json
from pathlib import Path
import time
import urllib.request
import pymysql

out=Path('output/nullable-v2-recheck/final')
records={'purpose':'One valid old count state, one old NULL state, and one new valid state. Full compaction must retain count 2.', 'sql':[], 'results':[], 'compaction':[]}
c=pymysql.connect(host='127.0.0.1',port=29745,user='root',database='nullable_migration')
s=c.cursor()
def sql(query):
 records['sql'].append(query);s.execute(query);rows=s.fetchall();records['results'].append(rows);return rows

def request(path,method='GET'):
 req=urllib.request.Request('http://127.0.0.1:28755'+path,method=method,headers={'Authorization':'Basic cm9vdDo='})
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 return json.loads(opener.open(req,timeout=60).read())

sql('set enable_agg_state=true');sql('set enable_sql_cache=false')
check='select count_merge(c) from old_fixed_count'
assert sql(check)==((1,),)
sql('insert into old_fixed_count select 1,count_state(cast(1 as int))')
assert sql(check)==((2,),)
rows=sql('show tablets from old_fixed_count');names=[v[0] for v in s.description]
for row in rows:
 tid=dict(zip(names,row))['TabletId']
 before=request(f'/api/compaction/show?tablet_id={tid}')
 trigger=request(f'/api/compaction/run?tablet_id={tid}&compact_type=full','POST')
 assert trigger['status']=='Success',trigger
 for attempt in range(120):
  status=request(f'/api/compaction/run_status?tablet_id={tid}')
  after=request(f'/api/compaction/show?tablet_id={tid}')
  if not status['run_status'] and len(after['rowsets'])<len(before['rowsets']):break
  time.sleep(.5)
 else:raise RuntimeError('compaction did not reduce rowsets')
 records['compaction'].append({'before':before,'trigger':trigger,'after':after})
assert sql(check)==((2,),)
(out/'fixed-count-compaction.json').write_text(json.dumps(records,indent=2,default=str)+'\n')
print('Old fixed COUNT plus new state and full compaction PASS')
