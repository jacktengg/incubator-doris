import datetime
import json
import os
from pathlib import Path
import subprocess

root=Path.cwd();out=root/'output/nullable-v2-recheck';p=out/'final'
summary=json.loads((p/'kernel-summary.json').read_text())
cases=[r['case'] for r in summary if r['migrated']['last_five_cv']>=.05]
commands=[]
for label,names in [('migrated',cases),('reference',['merge/nullable_decimal_avg/4096/1/1/64'])]:
 env=os.environ.copy();env['DORIS_HOME']=str(out/('performance' if label=='migrated' else 'reference-runtime')/'be')
 env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
 binary=out/'bin'/('sum-timing-benchmark' if label=='migrated' else 'reference-timing-benchmark')
 target=p/f'{label}-timing-recheck.json'
 original=p/f'{label}-timing.json'
 (p/f'{label}-timing-before-recheck.json').write_bytes(original.read_bytes())
 cmd=['taskset','-c','12',str(binary),'--benchmark_filter=^('+'|'.join(names)+')$',
      '--benchmark_min_time=5s','--benchmark_min_warmup_time=1','--benchmark_repetitions=5',
      '--benchmark_out='+str(target),'--benchmark_out_format=json']
 record={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (p/f'{label}-timing-recheck.log').open('w') as f:
  result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['exit_code']=result.returncode
 commands.append(record);(p/'kernel-recheck-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert result.returncode==0,label
 data=json.loads(original.read_text());data['benchmarks']+=json.loads(target.read_text())['benchmarks']
 # Replace the directory entry so the unchanged earlier reference hard link is retained.
 temporary=original.with_suffix('.tmp');temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(original)
 print(label,'long kernel recheck complete',flush=True)
