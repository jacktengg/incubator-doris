import datetime
import json
import os
from pathlib import Path
import statistics
import subprocess

root=Path.cwd();out=root/'output/nullable-v2-recheck';final=out/'final'
env=os.environ.copy();env['DORIS_HOME']=str(out/'performance/be')
env['LD_LIBRARY_PATH']='/mnt/disk2/tengjianping/local/jdk-17.0.2/lib/server:'+env.get('LD_LIBRARY_PATH','')
records=[];stress=[]
def run(variant,name,pattern,repetitions,minimum,warmup):
 target=final/(name+'.json')
 command=['taskset','-c','12',str(out/'bin'/f'sum-{variant}-benchmark'),
          '--benchmark_filter='+pattern,'--benchmark_min_time='+minimum,
          '--benchmark_min_warmup_time='+warmup,'--benchmark_repetitions='+str(repetitions),
          '--benchmark_out='+str(target),'--benchmark_out_format=json']
 record={'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record)
 with (final/(name+'.log')).open('w') as f:
  result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
 record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['exit_code']=result.returncode
 (final/'kernel-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0,name
 return json.loads(target.read_text())

for index in range(3):
 data=run('timing',f'migrated-all-null-stress-{index}','^streaming/nullable_sum/4096/100/1$',10,'0.5s','1')
 stress+=data['benchmarks']
 values=[r['cpu_time'] for r in data['benchmarks'] if r['run_type']=='iteration']
 print('all-null process',index,'mean',statistics.mean(values),'range',min(values),max(values),'CV',statistics.stdev(values)/statistics.mean(values),flush=True)

data=run('timing','migrated-timing-matrix','nullable_.*/4096/(0|1|50|100)/1($|/)',5,'0.5s','0.1')
data['benchmarks']+=stress
(final/'migrated-timing.json').write_text(json.dumps(data,indent=2)+'\n')
run('allocation','migrated-allocation','nullable_.*/4096/(0|1|50|100)/1($|/)',1,'0.001s','0')
rows=[json.loads(v.removeprefix('NULLABLE_ALLOCATIONS ')) for v in (final/'migrated-allocation.log').read_text().splitlines() if v.startswith('NULLABLE_ALLOCATIONS ')]
assert len(rows)==48
(final/'migrated-allocations.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in rows))
print('Final kernel matrix and counters complete',flush=True)
