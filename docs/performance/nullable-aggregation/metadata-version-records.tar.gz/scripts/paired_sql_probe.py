import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time
import pymysql

root = Path.cwd()
p = root / 'output/nullable-v2-recheck'
out = p / 'final/sql-paired-probe'
out.mkdir(exist_ok=True)
scripts = root / 'docs/performance/nullable-aggregation'
cases = ['numeric_low_null1', 'numeric_low_null50', 'numeric_low_null100',
         'wide_topn', 'tpcds_sf1_q78']
env = os.environ.copy()
env['JAVA_HOME'] = '/mnt/disk2/tengjianping/local/jdk-17.0.2'
for key in ('http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','all_proxy'):
    env.pop(key, None)
commands = []

def save():
    (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')

def run(args, name, cwd=root):
    record = {'command': list(map(str, args)), 'cwd': str(cwd),
              'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    commands.append(record)
    save()
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    record.update(exit_code=result.returncode,
                  end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    assert result.returncode == 0, name

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

for label, folder in [('reference-v2', 'reference-runtime'), ('migrated', 'performance')]:
    runtime = p / folder
    for part in ('fe', 'be'):
        assert not (runtime / part / 'bin' / (part + '.pid')).exists()
        run(['bin/start_' + part + '.sh', '--daemon'], label + '-start-' + part, runtime / part)
    time.sleep(30)
    for attempt in range(180):
        try:
            with pymysql.connect(host='127.0.0.1', port=29745, user='root', connect_timeout=3) as c, c.cursor() as s:
                s.execute('show backends')
                names = [v[0] for v in s.description]
                rows = [dict(zip(names, row)) for row in s.fetchall()]
                if len(rows) == 1 and str(rows[0]['Alive']).lower() == 'true':
                    break
        except (pymysql.MySQLError, ConnectionError):
            pass
        time.sleep(1)
    else:
        raise RuntimeError('cluster not ready: ' + label)
    pid = (runtime / 'be/bin/be.pid').read_text().strip()
    actual_hash = sha(Path('/proc') / pid / 'exe')
    assert actual_hash == sha(runtime / 'be/lib/doris_be')
    commands.append({'label': label, 'running_be_sha256': actual_hash})
    save()
    base = [sys.executable, str(scripts / 'run_queries.py'), label, '--port', '29745',
            '--http-port', '28745', '--output', str(out), '--v2', 'true']
    run(base + ['--repetitions', '0'], label + '-prewarm')
    run(base + ['--cases', ','.join(cases), '--repetitions', '5'], label + '-queries')
    for round_number in range(1, 4):
        data = json.loads((out / (label + '-queries.json')).read_text())['results']
        noisy = []
        for case in cases:
            values = [v['wall_seconds'] for v in data if v['case'] == case][-5:]
            if statistics.stdev(values) / statistics.mean(values) >= .05:
                noisy.append(case)
        if not noisy:
            break
        run(base + ['--append', '--cases', ','.join(noisy), '--repetitions', '5'],
            label + '-repeat-' + str(round_number))
    ids = {v['query_id'] for v in json.loads((out / (label + '-queries.json')).read_text())['results']}
    for attempt in range(60):
        audit = ''
        for file in sorted((runtime / 'fe/log').glob('fe.audit.log*')):
            if file.is_file():
                audit += gzip.open(file, 'rt').read() if file.suffix == '.gz' else file.read_text()
        if ids.issubset(set(re.findall(r'\|QueryId=([^|]+)', audit))):
            break
        time.sleep(1)
    else:
        raise RuntimeError('audit records missing')
    audit_path = p / (label + '-paired-complete-audit.log')
    audit_path.write_text(audit)
    run([sys.executable, str(scripts / 'collect_metrics.py'), label, str(audit_path),
         '--output', str(out)], label + '-metrics')
    for part in ('fe', 'be'):
        run(['bin/stop_' + part + '.sh'], label + '-stop-' + part, runtime / part)
        assert not (runtime / part / 'bin' / (part + '.pid')).exists()
    print(label, 'paired check complete; cluster stopped', flush=True)

data = {label: json.loads((out / (label + '-queries.json')).read_text())['results']
        for label in ('reference-v2', 'migrated')}
rows = []
for case in cases:
    row = {'case': case}
    for label in data:
        values = [v['wall_seconds'] * 1000 for v in data[label] if v['case'] == case]
        row[label] = {'n': len(values), 'mean_ms': statistics.mean(values),
                      'median_ms': statistics.median(values), 'min_ms': min(values),
                      'max_ms': max(values), 'last_five_mean_ms': statistics.mean(values[-5:]),
                      'last_five_cv': statistics.stdev(values[-5:]) / statistics.mean(values[-5:])}
    row['mean_change_pct'] = (row['migrated']['mean_ms'] / row['reference-v2']['mean_ms'] - 1) * 100
    rows.append(row)
(out / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2), flush=True)
