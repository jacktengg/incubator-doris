import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tarfile

root = Path.cwd()
docs = root / 'docs/performance/nullable-aggregation'
p = root / 'output/nullable-v2-recheck'
target = p / 'archive-check'
target.mkdir()
archive = docs / 'metadata-version-records.tar.gz'
with tarfile.open(archive) as tar:
    tar.extractall(target, filter='data')
inventory = json.loads((target / 'inventory.json').read_text())
for name, expected in inventory.items():
    path = target / name
    assert path.stat().st_size == expected['size'], name
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    assert h.hexdigest() == expected['sha256'], name
print('All archived file sizes and SHA256 hashes match:', len(inventory), flush=True)
output = target / 'regenerated'
output.mkdir()
for script in ['summarize.py', 'summarize_operators.py', 'summarize_kernels.py']:
    subprocess.run(['python3', str(target / 'records' / script), '--input',
                    str(target / 'records'), '--output', str(output),
                    '--prefix', 'metadata-version-'], check=True)
for path in output.iterdir():
    assert path.read_bytes() == (docs / path.name).read_bytes(), path
print('All six final summaries reproduce byte for byte.', flush=True)
spec = importlib.util.spec_from_file_location('operators', docs / 'summarize_operators.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
count = 0
for file in (target / 'records').glob('*-metrics.json'):
    for row in json.loads(file.read_text()):
        for operator in row['operators']:
            value = module.operator_times(operator['exec_time'])
            assert value['min'] <= value['avg'] <= value['max'], (file, row['case'], value)
            count += 1
print('Operator task min <= avg <= max:', count, flush=True)
