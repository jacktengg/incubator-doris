import hashlib
import io
import json
from pathlib import Path
import statistics
import subprocess
import tarfile

root = Path.cwd()
p = root / 'output/nullable-v2-recheck'
docs = root / 'docs/performance/nullable-aggregation'
records = p / 'final'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def write_new(path, value):
    if path.exists():
        path.unlink()
    path.write_text(json.dumps(value, indent=2) + '\n')

queries = {label: json.loads((records / (label + '-queries.json')).read_text())
           for label in ('reference-v1', 'reference-v2', 'migrated')}
stability = {}
for label, data in queries.items():
    stability[label] = {}
    for case in data['sql']:
        values = [v['wall_seconds'] for v in data['results'] if v['case'] == case]
        blocks = [values[i:i+5] for i in range(0, len(values), 5)]
        cvs = [statistics.stdev(v) / statistics.mean(v) for v in blocks]
        assert any(v < .05 for v in cvs), (label, case, cvs)
        stability[label][case] = {'repetitions': len(values), 'block_of_five_cv': cvs,
                                  'last_five_cv': cvs[-1]}
write_new(records / 'query-block-stability.json', stability)

counts = {label: len(data['results']) for label, data in queries.items()}
timings = {label: json.loads((records / (label + '-timing.json')).read_text())
           for label in ('reference', 'migrated')}
kernel_counts = {label: sum(v.get('run_type') == 'iteration' for v in data['benchmarks'])
                 for label, data in timings.items()}
method = dict(json.loads((p / 'current/method.json').read_text()))
method.update({
    'migrated_production_commit': json.loads((records / 'source.json').read_text())['migrated_production_commit'],
    'recorded_queries': counts,
    'sql_rounds': 'Reference records are reused unchanged. The final source has a new full-matrix prewarm, 5 per-case warmups, 10 recorded runs, then up to 5 blocks of 5 warmups and 5 recorded runs for cases whose last-five CV is at least 5%. All samples remain included.',
    'query_stability': stability,
    'kernel_all_null_sum': 'Final 219 source removes the c72 payload-load stall. CPU-12 primary statistics and separate CPU-37 pairs retain all samples.',
    'kernel_iteration_samples_in_primary_summary': kernel_counts,
    'paired_kernel_followup': 'cpu37-probe/summary.json; separate from CPU-12 primary statistics',
    'runtime_provenance_check': 'The production BE was built with ./build.sh --be -j12. The running /proc/PID/exe SHA256 must match binary-hashes.json before timing.',
    'earlier_sql_provenance_correction': 'build.sh --be --benchmark builds benchmark_test instead of doris_be. The 270-query cohort in pre-runtime-rebuild used c72 BE, although its kernel records used 219. It is excluded from the final SQL comparison.',
    'source_dataset': '4,000,000 deterministic source rows; 100,000 stored groups; TPC-DS SF1 and unchanged query78.sql',
    'paired_sql_followup': 'sql-paired-probe/summary.json and sql-reverse-probe/summary.json; 115 queries separate from the main SQL comparison',
    'limitations': ['Shared host and frequency scaling remain active.',
                    'Reference V1 TOPN final-five CV exceeds 5%; its first complete block is stable. Final migrated cases all have last-five CV below 5%.',
                    'Original private DORIS-29405 SQL and status are unverified.',
                    'Old bitmap bytes that collapsed no-input into empty cannot be recovered.']
})
write_new(records / 'method.json', method)

binary_paths = [p / 'reference-runtime/be/lib/doris_be',
                p / 'reference-runtime/fe/lib/doris-fe.jar',
                p / 'bin/reference-timing-benchmark', p / 'bin/reference-allocation-benchmark',
                p / 'bin/sum-timing-benchmark', p / 'bin/sum-allocation-benchmark',
                p / 'performance/be/lib/doris_be', p / 'performance/fe/lib/doris-fe.jar']
hashes = {str(f.relative_to(root)): sha(f) for f in binary_paths}
for name, value in json.loads((records / 'binary-hashes.json').read_text()).items():
    assert hashes[name] == value, name
source = json.loads((records / 'source.json').read_text())

files = []
for local, archived in [('current', 'before-sum-fix'), ('single-store-only', 'single-store-only'),
                        ('pre-runtime-rebuild', 'pre-runtime-rebuild'), ('final', 'records')]:
    for file in sorted((p / local).rglob('*')):
        assert not file.is_symlink(), file
        if file.is_file():
            files.append((file, archived + '/' + str(file.relative_to(p / local))))
for file in sorted(p.iterdir()):
    if file.is_file() and file.suffix == '.log' and 'complete-audit' not in file.name:
        files.append((file, 'validation/' + file.name))
for name in ['fe-replay.json', 'hardware-current.json', 'performance-ports.json', 'ports.json',
             'tpcds-data.sha256', 'tpcds-generator.sha256', 'tpcds-source-row-counts.json',
             'tpcds-sales-counts.txt', 'reference-benchmark.patch', 'measurement-custom_env.sh']:
    files.append((p / name, 'validation/' + name))
for name in ['run_kernels.py', 'recheck_kernels.py', 'final_sql_checks.py',
             'fixed_count_compaction.py', 'diagnose_all_null.py', 'measure_final_kernels.py',
             'diagnose_final_sum.py', 'final_kernel_recheck.py', 'measure_final_sql.py',
             'final_fixed_count_compaction.py', 'kernel_process_probes.py', 'kernel_cpu_probe.py',
             'recheck_cpu37_null_sum.py', 'prepare_rebuilt_runtime.py',
             'measure_rebuilt_runtime_sql.py', 'paired_sql_probe.py', 'reverse_sql_probe.py',
             'package_evidence.py', 'verify_packaged_evidence.py']:
    files.append((p / name, 'scripts/' + name))

inventory = {name: {'size': file.stat().st_size, 'sha256': sha(file)} for file, name in files}
archive = docs / 'metadata-version-records.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6, dereference=False) as tar:
    for file, name in files:
        tar.add(file, arcname=name, recursive=False)
    blob = (json.dumps(inventory, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('inventory.json')
    entry.size = len(blob)
    tar.addfile(entry, io.BytesIO(blob))
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert len(members) == len(files) + 1
    for member in members:
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        if member.islnk():
            assert member.linkname in inventory, member.linkname

manifest = {
    'sources': source,
    'archive': {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                'members': len(members), 'hard_links': sum(m.islnk() for m in members),
                'inventory': 'inventory.json'},
    'binaries_sha256': hashes,
    'recorded_final_comparison_queries': counts,
    'separate_paired_sql_queries': {'old_then_new': {'reference-v2': 55, 'migrated': 30},
                                  'new_then_old': {'reference-v2': 20, 'migrated': 10}},
    'kernel_iteration_samples_in_primary_summary': kernel_counts,
    'validation': {'be_asan': '409 tests in 67 suites pass', 'fe': '44 tests pass',
                   'sql': '20 AGG_STATE suites pass on the rebuilt final runtime',
                   'report_parser': '4 tests pass',
                   'style': 'clang-format 16, header hygiene, changed-line clang-tidy, FE Checkstyle pass'},
    'archive_layout': {
        'records': 'Final 219 production runtime and kernels; reused reference results are unchanged.',
        'before-sum-fix': 'c72 production/runtime measurements; original slow SUM samples retained.',
        'single-store-only': '18fb6a benchmark measurements; does not resolve the all-NULL stall.',
        'pre-runtime-rebuild': '219 kernels but c72 SQL runtime. The 270 SQL results are diagnostics, excluded from final SQL statistics.',
        'validation': 'Build/test/style/setup logs, including failed attempts and later passing retries. sum-final logs used c72; actual-runtime logs use the rebuilt final BE.',
        'scripts': 'Measured orchestration and packaging scripts. Committed drivers are also copied under records.'},
    'summary_sha256': {f.name: sha(f) for f in sorted(docs.glob('metadata-version-*-summary.*'))},
    'limitations': method['limitations']
}
(docs / 'metadata-version-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest['archive'], indent=2), flush=True)
