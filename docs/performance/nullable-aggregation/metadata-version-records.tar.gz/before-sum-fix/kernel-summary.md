<!--
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
-->

| Kernel/rows/NULL%/mode/groups | V1 us | V2 us | Migrated us [min,max] | vs V2 | Heap requests/op V2 → migrated | Heap bytes/op V2 → migrated |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| streaming/nullable_sum/4096/0/1 | 43.523 | 6.421 | 3.234 [3.217,3.247] | -49.6% | 7 → 5 | 139392 → 73856 |
| streaming/nullable_sum/4096/1/1 | 43.631 | 7.241 | 3.169 [3.119,3.245] | -56.2% | 7 → 5 | 139392 → 73856 |
| streaming/nullable_sum/4096/50/1 | 37.210 | 6.554 | 3.084 [3.074,3.101] | -52.9% | 7 → 5 | 139392 → 73856 |
| streaming/nullable_sum/4096/100/1 | 26.667 | 5.225 | 18.341 [1.786,89.144] | +251.0% | 7 → 5 | 139392 → 73856 |
| streaming/nullable_avg/4096/0/1 | 64.156 | 17.765 | 9.308 [9.183,9.378] | -47.6% | 7 → 5 | 434304 → 270464 |
| streaming/nullable_avg/4096/1/1 | 64.315 | 18.272 | 9.243 [9.173,9.325] | -49.4% | 7 → 5 | 434304 → 270464 |
| streaming/nullable_avg/4096/50/1 | 46.768 | 16.621 | 6.595 [6.509,6.663] | -60.3% | 7 → 5 | 434304 → 270464 |
| streaming/nullable_avg/4096/100/1 | 27.434 | 14.189 | 3.518 [3.454,3.564] | -75.2% | 7 → 5 | 434304 → 270464 |
| merge/nullable_sum/4096/0/1/64 | 6.703 | 4.359 | 3.749 [3.588,3.967] | -14.0% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/0/1/4096 | 13.675 | 11.795 | 12.313 [12.264,12.339] | +4.4% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/1/1/64 | 6.785 | 4.406 | 3.699 [3.539,4.189] | -16.0% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/1/1/4096 | 13.710 | 12.083 | 12.183 [12.035,12.370] | +0.8% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/50/1/64 | 5.814 | 4.467 | 3.401 [3.326,3.437] | -23.9% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/50/1/4096 | 12.961 | 12.051 | 11.486 [11.393,11.565] | -4.7% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/100/1/64 | 3.544 | 4.417 | 1.582 [1.574,1.591] | -64.2% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_sum/4096/100/1/4096 | 10.333 | 11.936 | 9.596 [9.556,9.634] | -19.6% | 0.0625 → 0 | 4096 → 0 |
| merge/nullable_avg/4096/0/1/64 | 12.253 | 7.474 | 7.331 [7.074,7.716] | -1.9% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/0/1/4096 | 23.402 | 20.389 | 17.247 [17.126,17.400] | -15.4% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/1/1/64 | 12.185 | 7.746 | 7.001 [6.916,7.119] | -9.6% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/1/1/4096 | 23.071 | 20.342 | 17.281 [17.078,17.778] | -15.0% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/50/1/64 | 9.630 | 7.560 | 4.355 [4.295,4.423] | -42.4% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/50/1/4096 | 20.202 | 20.392 | 14.960 [14.726,15.119] | -26.6% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/100/1/64 | 6.746 | 7.559 | 2.284 [2.231,2.352] | -69.8% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_avg/4096/100/1/4096 | 17.280 | 20.430 | 11.938 [11.786,12.102] | -41.6% | 0.0625 → 0 | 12288 → 0 |
| streaming/nullable_decimal_sum/4096/0/1 | 50.787 | 10.318 | 2.876 [2.759,3.017] | -72.1% | 7 → 5 | 237696 → 139392 |
| streaming/nullable_decimal_sum/4096/1/1 | 50.750 | 11.084 | 2.771 [2.729,2.812] | -75.0% | 7 → 5 | 237696 → 139392 |
| streaming/nullable_decimal_sum/4096/50/1 | 41.226 | 9.396 | 2.913 [2.878,2.938] | -69.0% | 7 → 5 | 237696 → 139392 |
| streaming/nullable_decimal_sum/4096/100/1 | 26.936 | 7.597 | 2.039 [2.018,2.086] | -73.2% | 7 → 5 | 237696 → 139392 |
| streaming/nullable_decimal_avg/4096/0/1 | 64.765 | 17.978 | 9.099 [9.073,9.116] | -49.4% | 7 → 5 | 434304 → 270464 |
| streaming/nullable_decimal_avg/4096/1/1 | 64.393 | 19.287 | 9.121 [9.059,9.148] | -52.7% | 7 → 5 | 434304 → 270464 |
| streaming/nullable_decimal_avg/4096/50/1 | 48.450 | 17.003 | 6.378 [6.314,6.443] | -62.5% | 7 → 5 | 434304 → 270464 |
| streaming/nullable_decimal_avg/4096/100/1 | 27.671 | 15.484 | 3.500 [3.470,3.531] | -77.4% | 7 → 5 | 434304 → 270464 |
| merge/nullable_decimal_sum/4096/0/1/64 | 9.389 | 5.900 | 5.835 [5.543,6.017] | -1.1% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/0/1/4096 | 17.213 | 14.502 | 13.339 [13.221,13.590] | -8.0% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/1/1/64 | 9.237 | 5.960 | 5.978 [5.916,6.090] | +0.3% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/1/1/4096 | 17.522 | 14.514 | 13.284 [13.184,13.359] | -8.5% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/50/1/64 | 6.867 | 5.938 | 3.674 [3.621,3.763] | -38.1% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/50/1/4096 | 14.763 | 14.669 | 11.086 [10.904,11.529] | -24.4% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/100/1/64 | 4.809 | 6.006 | 1.550 [1.516,1.576] | -74.2% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_sum/4096/100/1/4096 | 11.852 | 14.538 | 8.589 [8.489,8.790] | -40.9% | 0.0625 → 0 | 8192 → 0 |
| merge/nullable_decimal_avg/4096/0/1/64 | 12.260 | 7.309 | 7.173 [7.023,7.264] | -1.9% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/0/1/4096 | 23.407 | 20.300 | 17.585 [17.475,17.715] | -13.4% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/1/1/64 | 12.252 | 7.517 | 7.217 [7.093,7.342] | -4.0% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/1/1/4096 | 23.673 | 20.425 | 17.528 [17.444,17.744] | -14.2% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/50/1/64 | 9.529 | 7.422 | 4.320 [4.268,4.382] | -41.8% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/50/1/4096 | 20.231 | 20.293 | 14.833 [14.732,15.024] | -26.9% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/100/1/64 | 6.797 | 7.390 | 1.508 [1.505,1.510] | -79.6% | 0.0625 → 0 | 12288 → 0 |
| merge/nullable_decimal_avg/4096/100/1/4096 | 16.880 | 20.436 | 11.583 [11.382,12.008] | -43.3% | 0.0625 → 0 | 12288 → 0 |
