<!--
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
-->

| Case | V1 ms | V2 ms | Migrated ms [min,max] | vs V2 | Peak MiB (V2 → migrated) |
| --- | ---: | ---: | ---: | ---: | ---: |
| numeric_low_null0 | 36.95 | 36.36 | 36.36 [31.12,45.14] | -0.0% | 244.0 → 248.7 |
| numeric_high_null0 | 187.57 | 175.71 | 175.06 [152.97,207.26] | -0.4% | 812.1 → 792.6 |
| variadic_null0 | 82.68 | 84.81 | 64.20 [59.12,79.95] | -24.3% | 308.2 → 290.0 |
| numeric_low_null1 | 34.87 | 36.96 | 38.45 [36.45,42.84] | +4.0% | 213.4 → 221.9 |
| numeric_high_null1 | 185.39 | 182.17 | 179.35 [158.30,217.93] | -1.5% | 764.3 → 812.8 |
| variadic_null1 | 83.20 | 88.33 | 70.35 [65.10,75.74] | -20.4% | 276.9 → 288.3 |
| numeric_low_null50 | 40.58 | 38.52 | 39.31 [36.37,46.49] | +2.1% | 234.6 → 244.3 |
| numeric_high_null50 | 200.03 | 195.93 | 174.81 [160.13,194.01] | -10.8% | 794.5 → 812.3 |
| variadic_null50 | 87.60 | 82.57 | 66.01 [62.70,78.60] | -20.1% | 285.3 → 278.7 |
| numeric_low_null100 | 33.32 | 33.27 | 33.56 [32.16,35.44] | +0.9% | 223.1 → 244.3 |
| numeric_high_null100 | 106.95 | 172.07 | 119.58 [108.08,138.86] | -30.5% | 781.3 → 763.6 |
| variadic_null100 | 64.58 | 65.10 | 49.60 [44.52,60.07] | -23.8% | 284.6 → 284.3 |
| wide_string_set | 1219.02 | 1243.99 | 1236.77 [1202.98,1268.45] | -0.6% | 2679.6 → 2687.9 |
| wide_string_streaming | 351.55 | 354.63 | 329.29 [306.42,358.35] | -7.1% | 1020.8 → 1019.9 |
| wide_topn | 537.22 | 549.17 | 562.29 [493.92,964.73] | +2.4% | 348.9 → 345.7 |
| stored_merge | 62.42 | 63.17 | 63.19 [56.73,71.78] | +0.0% | 188.3 → 211.6 |
| stored_union_finalize | 15.84 | 15.93 | 16.49 [12.93,22.34] | +3.5% | 218.8 → 218.8 |
| stored_bulk_merge | 45.58 | 44.68 | 43.82 [40.88,46.10] | -1.9% | 262.1 → 263.6 |
| stored_bulk_union_finalize | 29.45 | 29.96 | 27.61 [24.92,31.17] | -7.8% | 175.1 → 176.6 |
| stored_bulk_wide | 735.57 | 740.64 | 711.15 [696.95,724.98] | -4.0% | 1066.6 → 1065.3 |
| tpcds_sf1_q78 | 134.46 | 135.66 | 131.59 [116.60,161.98] | -3.0% | 1668.9 → 1688.5 |
